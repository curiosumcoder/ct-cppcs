#pragma once

void SmartPointers();
